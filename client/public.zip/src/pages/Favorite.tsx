import Container from "../ui/Container";

const Favorite = () => {
  return <Container>Favorite</Container>;
};

export default Favorite;
