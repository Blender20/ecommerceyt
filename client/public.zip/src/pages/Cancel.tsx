import Container from "../ui/Container";

const Cancel = () => {
  return <Container>Cancel</Container>;
};

export default Cancel;
